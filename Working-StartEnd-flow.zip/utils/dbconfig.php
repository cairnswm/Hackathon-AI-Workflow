<?php

$dbconfig = [
    'host' => 'cairns.co.za',
    'username' => 'cairnsco_workflow',
    'password' => 'cairnsco_workflow',
    'database' => 'cairnsco_workflow'
];
