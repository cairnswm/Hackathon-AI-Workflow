<?php
class WorkflowNode {
    protected $id;
    protected $type;

    public function __construct($id, $type) {
        $this->id = $id;
        $this->type = $type;
    }

    public function run($config) {
        $this->start($config);

        $result = $this->execute($config);

        $this->audit($config, $result);

        return $this->end($config, $result);
    }

    protected function start($config) {
        // Parent start logic: validate inputs
        if (!isset($config['workflow_run_id']) || !isset($config['node_config'])) {
            throw new Exception("Missing required configuration data.");
        }

        // Allow child classes to extend this method with additional validation or setup
    }

    protected function execute($config) {
        // Default execution - pass through the workflow data
        $result = [
            'status' => 'ok',
            'output' => $config['workflow_data']
        ];

        return $result;
    }

    protected function audit($config, $result) {
        $workflowRunId = $config['workflow_run_id'];
        $nodeConfig = json_encode($config['node_config']);
        $localData = json_encode($config['local_data'] ?? []);
        $resultData = json_encode($result);

        $sql = "INSERT INTO workflow_run_steps (workflow_run_id, node_id, node_type, input_data, output_data, started_at, ended_at)
                VALUES (?, ?, ?, ?, ?, NOW(), NULL)";

        executeSQL($sql, [
            $workflowRunId,
            $this->id,
            $this->type,
            $nodeConfig,
            $resultData
        ]);
    }

    protected function end($config, $result) {
        // Determine status based on node type
        $status = $this->type === 'start' ? 'ok' : 'end';

        return [
            'status' => $status,
            'result' => $result
        ];
    }
}