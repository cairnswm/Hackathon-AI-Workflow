<?php

require_once __DIR__ . '/../nodes/workflownode.php';

class WorkflowEngine
{
  public function start($workflowId, $inputData)
  {
    // Insert new workflow run using insertRecord
    $inputJson = json_encode($inputData);
    $status = 'running';

    $workflowRun = insertRecord(
      "INSERT INTO workflow_runs (workflow_id, status, input_data, created_at, modified_at)
             VALUES (?, ?, ?, NOW(), NOW())",
      [$workflowId, $status, $inputJson]
    );

    if (!$workflowRun) {
      throw new Exception("Failed to create workflow run");
    }

    // Access the first record in $workflowRun if it is an array of records
    if (is_array($workflowRun) && isset($workflowRun[0]) && is_array($workflowRun[0]) && array_key_exists('id', $workflowRun[0])) {
      $workflowRunId = $workflowRun[0]['id'];
    } else {
      throw new Exception("Invalid workflow run structure: " . json_encode($workflowRun));
    }

    // Start processing the workflow
    return $this->run($workflowId, $workflowRunId, $inputData);
  }

  private function executeNode($nodeId, $nodeType, $nodeConfig, $workflowRunId, $workflowData, $previousNodeId = null)
  {
    $microtimeStart = microtime(true);
    $workflowNode = new WorkflowNode($nodeId, $nodeType);
    $result = $workflowNode->run([
      'workflow_run_id' => $workflowRunId,
      'node_config' => $nodeConfig,
      'workflow_data' => $workflowData,
      'local_data' => []
    ]);

    $updatedWorkflowData = $result['workflow_data'] ?? $workflowData;

    $logEntry = [
      'node_id' => $nodeId,
      'node_type' => $nodeType,
      'previous_node_id' => $previousNodeId,
      'output' => $result['result'],
      'started_at' => date('Y-m-d H:i:s', $microtimeStart) . sprintf('.%03d', ($microtimeStart - floor($microtimeStart)) * 1000)
    ];

    if ($nodeType === 'end') {
      $microtimeEnd = microtime(true);
      $logEntry['ended_at'] = date('Y-m-d H:i:s', $microtimeEnd) . sprintf('.%03d', ($microtimeEnd - floor($microtimeEnd)) * 1000);
    }

    $this->updateExecutionLog($workflowRunId, $logEntry);

    return [
      'status' => $result['status'],
      'result' => $result['result'],
      'workflow_data' => $updatedWorkflowData
    ];
  }

  public function run($workflowId, $workflowRunId, $inputData)
  {
    $rows = executeSQL("SELECT id, type, config FROM workflow_nodes WHERE workflow_id = ?", [$workflowId], true);
    $edges = executeSQL("SELECT from_node_id, to_node_id FROM workflow_edges WHERE workflow_id = ?", [$workflowId], true);

    $nodes = [];
    if (is_array($rows)) {
      foreach ($rows as $row) {
        if (is_array($row) && isset($row['id'], $row['type'], $row['config'])) {
          $decodedConfig = $row['config'] !== null ? json_decode($row['config'], true) : [];
          if ($decodedConfig === null && json_last_error() !== JSON_ERROR_NONE) {
            echo "Invalid JSON in config for node ID: {$row['id']}\n";
            continue;
          }

          $nodes[$row['id']] = [
            'type' => $row['type'],
            'config' => $decodedConfig
          ];
        } else {
          echo "Invalid row structure: ";
          var_dump($row);
        }
      }
    } else {
      echo "Expected rows to be an array, but got: ";
      var_dump($rows);
    }

    $endNodeOutput = null;

    foreach ($nodes as $nodeId => $node) {
      if ($node['type'] === 'start') {
        $result = $this->executeNode($nodeId, $node['type'], $node['config'], $workflowRunId, $inputData);

        if ($result['status'] === 'wait' || $result['status'] === 'end') {
          return $result['result'];
        }

        $endNodeOutput = $this->processNextNodes($nodeId, $nodes, $edges, $workflowRunId, $result['workflow_data']);
        break;
      }
    }

    return [
      'status' => 'success',
      'output' => $endNodeOutput
    ];
  }

  private function processNextNodes($currentNodeId, $nodes, $edges, $workflowRunId, $workflowData)
  {
    $output = [];
    foreach ($edges as $edge) {
      if ($edge['from_node_id'] === $currentNodeId && isset($nodes[$edge['to_node_id']])) {
        $nextNodeId = $edge['to_node_id'];
        $node = $nodes[$nextNodeId];

        $result = $this->executeNode($nextNodeId, $node['type'], $node['config'], $workflowRunId, $workflowData, $currentNodeId);

        if ($result['status'] === 'wait' || $result['status'] === 'end') {
          return $result['result'];
        } elseif ($result['status'] === 'error') {
          throw new Exception("Error in node ID: $nextNodeId");
        }

        // Ensure recursive call continues for subsequent nodes
        $nextResult = $this->processNextNodes($nextNodeId, $nodes, $edges, $workflowRunId, $result['workflow_data']);
        if ($nextResult !== null) {
          $output = $nextResult;
        }
        echo "Processed node ID: $nextNodeId\n";
        var_dump($nextResult);
        if ($nextResult !== null) {
          return $nextResult;
        }
      }
    }

    return $output;
  }

  private function getExecutionLog($workflowRunId)
  {
    $executionLog = executeSQL(
      "SELECT execution_log FROM workflow_runs WHERE id = ?",
      [$workflowRunId],
      true
    );

    $executionLog = is_array($executionLog) && isset($executionLog[0]['execution_log'])
      ? json_decode($executionLog[0]['execution_log'], true)
      : [];

    return is_array($executionLog) ? $executionLog : [];
  }

  private function updateExecutionLog($workflowRunId, $logEntry)
  {
    $executionLog = $this->getExecutionLog($workflowRunId);
    $executionLog[] = $logEntry;

    executeSQL(
      "UPDATE workflow_runs SET execution_log = ? WHERE id = ?",
      [json_encode($executionLog), $workflowRunId]
    );
  }
}